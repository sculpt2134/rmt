/*
 * Date   : 2016.12.15
 * Author : contentstech
 * Desc   : util
 */
!function () {

}();
"function"===typeof importScripts&&importScripts("https://api.useinsider.com/sw.js");
